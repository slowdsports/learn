# Rock-Paper-Scissors

First project on my learnig path using Javascript, as a part of the **#100DaysOfCode** challenge.

The idea came from the Basic Javascript Course from Platzi and took as a reference the tutorials of @TraversiMedia and @whatsdev to understand better the concepts and improve my design. 

**You can check it right here:** https://iamdulce.github.io/rock-paper-scissors-/
